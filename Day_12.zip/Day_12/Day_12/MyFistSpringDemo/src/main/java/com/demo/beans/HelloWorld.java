package com.demo.beans;

public class HelloWorld {
	public void sayHello() {
		System.out.println("Hello world!!");
	}
	public HelloWorld() {
		System.out.println("in default constuctor");
	}

}
