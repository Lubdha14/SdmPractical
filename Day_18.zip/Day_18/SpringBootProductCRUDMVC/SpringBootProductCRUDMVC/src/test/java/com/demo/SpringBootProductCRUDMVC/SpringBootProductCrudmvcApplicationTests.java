package com.demo.SpringBootProductCRUDMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProductCrudmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
